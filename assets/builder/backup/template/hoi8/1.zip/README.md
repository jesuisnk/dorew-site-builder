# dorew-site.github.io
> Code Jekyll VF Lite cho DorewSite

**Bản Lite có gì hot?**
- Chẳng có gì hot, hơn nữa, bản lite còn bị lược bỏ đi nhiều tính năng.
- Bảng dữ liệu mới không tương ứng với dữ liệu cũ.

**Tính năng:**
- Đăng ký, đăng nhập, danh sách thành viên
- Thông tin thành viên, danh sách bài viết của thành viên đó
- Phòng chat autoload, tải file lên ipfs và imgur qua chatbox
- Tạo, chỉnh sửa, xoá bài viết và chuyên mục
- Bài viết VIP, bình luận bài viết

**Một số hình ảnh:**


![](https://i.imgur.com/0kuLQ7I.png)


![](https://i.imgur.com/7f91opi.png)


![](https://i.imgur.com/TRtZfAN.png)


![](https://i.imgur.com/eMw0vbZ.png)


![](https://i.imgur.com/1gHJQT5.png)


**Hướng dẫn cài đặt:**
- Truy cập: **/cms** -> Đăng nhập -> **Sao lưu** -> **Tải lên template** -> Chọn zip vừa tải về -> **Sử dụng**
- Tệp **_install** dùng để khởi tạo các bảng dữ liệu của code, vui lòng không xoá nó.
- Nếu cơ sở dữ liệu đã có sẵn các bảng này (trong _install) nhưng khác cấu trúc, hãy backup và dọn dẹp chúng, sau đó bắt đầu cài đặt dữ liệu mới: truy cập vào index của website.

*Vì đây là bản lite nên khá sơ sài, ae múc về thêm mắm thêm muối vào cho vừa vị nha*